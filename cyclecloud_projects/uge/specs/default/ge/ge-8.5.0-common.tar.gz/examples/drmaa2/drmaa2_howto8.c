#include <stdio.h>
#include <stdlib.h>
#include "drmaa2.h"
#include "drmaa2_test_helper.h"

int main(int argc, char** argv) {

    int size, i;
    drmaa2_msession ms = drmaa2_open_msession("my_m_session");

    if (ms == NULL) {
        drmaa2_string error = drmaa2_lasterror_text();
        fprintf(stderr, "Error during opening/creating a session: %s\n", error);
        return EXIT_FAILURE;
    } else {
        /* get all filter */
        drmaa2_jinfo jinfo = drmaa2_jinfo_create();

        drmaa2_j_list jobs = drmaa2_msession_get_all_jobs(ms, jinfo);

        size = drmaa2_list_size(jobs);

        printf("%d job(s) in the system with names as follows:\n", size);

        for (i = 0; i < size; i++) {
            drmaa2_j rjob = (drmaa2_j) drmaa2_list_get(jobs, i);
            drmaa2_jinfo jinfo2 = drmaa2_j_get_info(rjob);

            if (drmaa2_j_get_id(rjob) != NULL) {
                fprintf(stdout, "Job with id %s.\n", (char *) drmaa2_j_get_id(rjob));
            } else {
                fprintf(stdout, "Job has unknown id.\n");
            }

            print_jinfo(jinfo2, stdout);
#if 0
            // HERE IS THE ISSE, NOT ALL JOBS HAVE JOB NAME (ONLY RUNNING)
            if (jinfo2->jobName != NULL)
               printf("%s\n", jinfo2->jobName);
            if (jinfo2->jobId != NULL)
               printf("%s\n", jinfo2->jobId);
            if (jinfo2->jobOwner != NULL)
               printf("jobOwner %s\n", jinfo2->jobOwner);
#endif            
            drmaa2_j_free(&rjob);
        }

        // drmaa2_list_free(&jobs);

        drmaa2_close_msession(ms);
        ms = NULL;

        return EXIT_SUCCESS;
    }
}
