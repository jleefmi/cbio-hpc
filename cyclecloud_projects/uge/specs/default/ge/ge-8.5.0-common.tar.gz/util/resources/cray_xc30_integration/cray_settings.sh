#!/bin/sh

#######################################################################
# NOTE: Please adjust the path according to your machine, otherwise the
# Grid Engine Prolog and Epilog will not find the apbasil binary!
# Hint: Copy full path you have on login node command line at the end
# of the colon.
#######################################################################

export PATH=$PATH:

