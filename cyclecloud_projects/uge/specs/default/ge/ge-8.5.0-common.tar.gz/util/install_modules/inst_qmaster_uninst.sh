#!/bin/sh
#
# SGE configuration script (Installation/Uninstallation/Upgrade/Downgrade)
# Scriptname: inst_qmaster_uninst.sh
#
#___INFO__MARK_BEGIN__
##########################################################################
#
#  The Contents of this file are made available subject to the terms of
#  the Sun Industry Standards Source License Version 1.2
#
#  Sun Microsystems Inc., March, 2001
#
#
#  Sun Industry Standards Source License Version 1.2
#  =================================================
#  The contents of this file are subject to the Sun Industry Standards
#  Source License Version 1.2 (the "License"); You may not use this file
#  except in compliance with the License. You may obtain a copy of the
#  License at http://gridengine.sunsource.net/Gridengine_SISSL_license.html
#
#  Software provided under this License is provided on an "AS IS" basis,
#  WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING,
#  WITHOUT LIMITATION, WARRANTIES THAT THE SOFTWARE IS FREE OF DEFECTS,
#  MERCHANTABLE, FIT FOR A PARTICULAR PURPOSE, OR NON-INFRINGING.
#  See the License for the specific provisions governing your rights and
#  obligations concerning the Software.
#
#  The Initial Developer of the Original Code is: Sun Microsystems, Inc.
#
#  Copyright: 2001 by Sun Microsystems, Inc.
#
#  All Rights Reserved.
#
#  Portions of this software are Copyright (c) 2014 Univa Corporation
#
##########################################################################
#___INFO__MARK_END__
#
# set -x

if [ "$LO" = true ]; then
   qconf_bin="loconf"
   qmaster_name="lomaster"
else
   qconf_bin="qconf"
   qmaster_name="qmaster"
fi

RemoveQmaster()
{
   $INFOTEXT -u "Uninstalling $qmaster_name host"
   $INFOTEXT -n "You're going to uninstall the $qmaster_name host now. If you are not sure,\n" \
                "what you are doing, please stop with <CTRL-C>. This procedure will, remove\n" \
                "the complete cluster configuration and all spool directories!\n" \
                "Please make a backup from your cluster configuration!\n\n"
   if [ $AUTO = "false" ]; then
      $INFOTEXT -n -ask "y" "n" -def "n" "Do you want to uninstall the master host? [n] >> "
   fi

   if [ $? = 0 ]; then
      $INFOTEXT -n "We're going to uninstall the master host now!\n"
      CheckRegisteredExecd

   else
      MoveLog
      exit 0 
   fi
}

CheckRegisteredExecd()
{
   $INFOTEXT -n "Checking Running Execution Hosts\n"
   $INFOTEXT -log -n "Checking Running Execution Hosts\n"

   LO_ENABLE_QCONF_OPTIONS=1
   export LO_ENABLE_QCONF_OPTIONS
   registered=`$qconf_bin -sel`
   unset LO_ENABLE_QCONF_OPTIONS

     if [ "$registered" = "" ]; then
        :
     else
        $INFOTEXT "Found registered execution hosts, exiting uninstallation!\n"
        $INFOTEXT -log "Found registered execution hosts, exiting uninstallation!\n"
        MoveLog
        exit 1 
     fi

   $INFOTEXT "There are no running execution host registered!\n"
   $INFOTEXT -log "There are no running execution host registered!\n"
   ShutdownMaster
   

}

ShutdownMaster()
{
   euid=`$SGE_UTILBIN/uidgid -euid`
   GetAdminUser

   if [ "$LO" = "true" ]; then
      SGE_ROOT=$LO_ROOT
      SGE_CELL=$LO_CELL
   fi
	#When non-root, can't manage SMF
   if [ "$euid" != 0 -o "$SGE_ENABLE_SMF" != "true" ]; then
      $INFOTEXT "Shutting down $qmaster_name!"
      $INFOTEXT -log "Shutting down $qmaster_name!"
      spool_dir_master=`cat $SGE_ROOT/$SGE_CELL/common/bootstrap | grep qmaster_spool_dir | awk '{ print $2 }'`
      master_pid=`cat $spool_dir_master/qmaster.pid`

      $SGE_BIN/$qconf_bin -km

      ret=0
      while [ $ret -eq 0 ]; do 
         if [ ! -z "$master_pid" ]; then
            $SGE_UTILBIN/checkprog $master_pid sge_qmaster > /dev/null
            ret=$?
         else
            ret=1
         fi
         $INFOTEXT "sge_$qmaster_name is going down ...., please wait!"
         sleep 5
      done

      $INFOTEXT "sge_$qmaster_name is down!"
   fi

   master_spool=`cat $SGE_ROOT/$SGE_CELL/common/bootstrap | grep qmaster_spool_dir | awk '{ print $2 }'`
   reporting=$SGE_ROOT/$SGE_CELL/reporting
   
   toDelete="accounting act_qmaster bootstrap cluster_name configuration jmx local_conf qtask sched_configuration sgeCA sge_request sgemaster"
   

   if [ -f $SGE_ROOT/$SGE_CELL/common/sgebdb ]; then
      $INFOTEXT "Berkeley db server is being used with this installation"
      $INFOTEXT "Skipping removal of berkeley spool directory"
      $INFOTEXT "Uninstall the berkeley db server before removing the spool directory"
   else
      berkeley_spool=`cat $SGE_ROOT/$SGE_CELL/common/bootstrap | grep spooling_params | awk '{ print $2 }'`

      $INFOTEXT "Removing berkeley spool directory!"
      $INFOTEXT -log "Removing berkeley spool directory!"
      ExecuteAsAdmin $RM -rf $berkeley_spool
   fi

   $INFOTEXT "Removing $qmaster_name spool directory!"
   $INFOTEXT -log "Removing $qmaster_name spool directory!"
   ExecuteAsAdmin $RM -fR $master_spool

   $INFOTEXT "Removing reporting file"
   $INFOTEXT -log "Removing reporting file"
   ExecuteAsAdmin $RM $reporting

   for path in $toDelete
   do
     if [ -f $SGE_ROOT/$SGE_CELL/common/$path ]; then
         $INFOTEXT "Removing $path"
         $INFOTEXT -log "Removing $SGE_ROOT/$SGE_CELL/common/$path"
         ExecuteAsAdmin $RM -rf $SGE_ROOT/$SGE_CELL/common/$path
      fi
   done


  # RemoveRcScript $HOST master $euid

  #Detect execd service/rc script
   if [ "$LO" = "true" ]; then
      CheckIfClusterNameAlreadyExists "lomaster" "uninstall"
      RemoveRC_SMF "lomaster" $?
   else  
      CheckIfClusterNameAlreadyExists "master" "uninstall"
      #And remove either or both 
      RemoveRC_SMF "master" $?
   fi
}

